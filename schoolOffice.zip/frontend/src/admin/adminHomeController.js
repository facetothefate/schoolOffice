angular.module('school-office').controller('AdminHomeController',function($scope,$rootScope){

});
