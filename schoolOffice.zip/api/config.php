<?php
    $config = [
        "host" => "localhost",
        "user" => "root",
        "passwd" => "",
        "db" => "school_office",
        "https" => false,
        "auth-header" => 'Token-Authorization-X',
        "site-email" => 'no-reply@capital-international.ca'
    ]
 ?>
